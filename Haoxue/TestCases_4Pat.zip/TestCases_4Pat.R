#### Loading Files ####
##Load all files from RDA
load(file = "./Covid_StressMemory_4pat.rda")

#Stress_Change_LongBel <- read.csv("../Johnny/StressChanges_Long.csv", header = TRUE) #Import data on Changes in stress between TP1 and TP2, Long Format
#DevxConf_Type <- read.csv("../Johnny/Deviations_BelExp.csv", header = TRUE) #Import data on Deviations of Remembered Belief/Experience-related stress
#df.pca.long <- read.csv('data/df.pca.long.csv') %>% mutate(Subject = factor(Subject))

##Load Contingencies and Packages
if(!require("pacman")) install.packages("pacman") #Install pacman to facilitate package installing/loading
p_load(tidyverse, ggplot2, tidyr, dplyr, BayesFactor, brms, lme4, sjPlot, rstanarm, bayestestR) #Load necessary rPackages
if(!require("terra")){install.packages('terra', repos='https://rspatial.r-universe.dev'); require("terra")}
require("devtools")
if(!require("INLA")){install.packages("INLA",repos=c(getOption("repos"),INLA="https://inla.r-inla-download.org/R/testing"), dep=TRUE); require("INLA")}
inla.setOption(mkl=TRUE)
if (!require("INLAutils")) {install_github("timcdlucas/INLAutils"); require("INLAutils")}  ## additional plotting utilities 
if (!require("brinla")) {install_github("julianfaraway/brinla"); require("brinla")}   ## additional inla functions
if (!require("coefINLA")) {install_github("hesscl/coefINLA"); require("coefINLA")}    ## nice plots for inla models
#if (!require("rstanarm")) {install.packages("rstanarm"); require("rstanarm")} 
if (!require("INLAOutputs")) {install_github('oswaldosantos/INLAOutputs'); require("INLAOutputs")}
options(mc.cores = parallel::detectCores())

#### Test Case #1 ####
## Overall change in belief-related stress // Random slope for each stress related question
#Data Preparation
Stress_Change_LongBel$Subject <- as.factor(Stress_Change_LongBel$Subject)
Stress_Change_LongBel$Question <- as.factor(Stress_Change_LongBel$Question)

#Preparation for INLA Random Slope
nid <- length(Stress_Change_LongBel$Subject)       ## number of persons in the sample
nid
int_id <- as.numeric(Stress_Change_LongBel$Subject)        ## numeric representation on the random effect (intercept ID)
int_id
slope_id <- int_id + nid
slope_id

inla_BelStress_Ovrl <- inla(Rating ~ TP + f(int_id, model = "iid2d", n = 2*nid) + f(slope_id, Question, copy = "int_id"), family = "beta", data = Stress_Change_LongBel, verbose = TRUE) 
summary(inla_BelStress_Ovrl) # Summarize results
coefINLA(inla_BelStress_Ovrl) # fixed effects
#Overall Belief-related stress was greater in the past


#### Test Case #2 ####
## Differences in Remembered Stress by type:Exp/Bel (N = 728) ##
#Data Preparation
DevxConf_Type$Subject <- as.factor(DevxConf_Type$Subject)
DevxConf_Type$Q <- as.factor(DevxConf_Type$Q)
DevxConf_Type$Mem <- as.factor(DevxConf_Type$Mem)
DevxConf_Type$Conf_Rat <- factor(DevxConf_Type$Conf_Rat, levels = c("Low", "Med", "High"))

#Preparation for INLA Random Slope
nid <- length(table(DevxConf_Type$Subject))       ## number of persons in the sample
nid
int_id <- as.numeric(DevxConf_Type$Subject)        ## numeric representation on the random effect (intercept ID)
int_id
slope_id <- int_id + nid
slope_id

#Analysis
DevxConf_Type %>% group_by(Mem) %>% summarise(avg_Dev = mean(Deviation))

inla_Dev_Type <- inla(BDev ~ Mem + f(int_id, model = "iid2d", n = 2*nid) + f(slope_id, Q, copy = "int_id"), family = "beta", data = DevxConf_Type, verbose = TRUE) 
summary(inla_Dev_Type) #Summarize results
coefINLA(inla_Dev_Type) #Fixed effects
# Participants tended to overestimate belief-related stress more than experience-related stress

#### Test Case #3 ####
## Research Q: How does delta_pca_score influence deviation (after controlling for T1_experienced, T2_experienced, and delta_soc)
##             Each subject has 17 deviation_squeeze
##             Ideal model: deviation_squeeze ~ T1_experienced + T2_experienced + delta_pca_score + delta_soc + (1|Subject) + (1|Question)
##             Would also love to know how to include random slope e.g. (T1_experienced + T2_experienced + delta_pca_score + delta_soc | Subject)
df.pca.long$Subject <- as.factor(df.pca.long$Subject)
df.pca.long$Question <- as.factor(df.pca.long$Question)
nid <- length(table(df.pca.long$Subject))       ## number of persons in the sample
nid
int_id <- as.numeric(df.pca.long$Subject)        ## numeric representation on the random effect (intercept ID)
int_id
slope_id <- int_id + nid
slope_id
inla_DeltaPCA_long <- inla(deviation_squeeze ~ T1_experienced + T2_experienced + delta_pca_score + delta_soc + 
                        f(int_id, model = "iid2d", n = 2*nid)  + 
                        f(slope_id, Question, copy = "int_id"), 
                      family = 'beta', data = df.pca.long, verbose = TRUE) 

summary(inla_DeltaPCA_long) #Summarize results
coefINLA(inla_DeltaPCA_long) #Fixed effects

save(Stress_Change_LongBel, DevxConf_Type, df.pca.long, 
     inla_BelStress_Ovrl, inla_Dev_Type, inla_DeltaPCA_long,
     file="Covid_StressMemory_4pat.rda")
